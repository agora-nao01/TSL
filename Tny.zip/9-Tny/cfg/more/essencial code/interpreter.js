const fs = require("fs");

// 1. lê config de linguagem
function loadLanguage(lang) {
    const path = `repo/cfg/language/${lang.toLowerCase()}.json`;
    return JSON.parse(fs.readFileSync(path, "utf-8"));
}

// 2. aplica abreviações (SEM exceção)
function applyAbbreviations(text, dict) {
    for (let short in dict) {
        const full = dict[short];

        // replace global seguro
        text = text.split(short).join(full);
    }
    return text;
}

// 3. processa repetição (PARENTÊSES)
function applyRepeats(text) {
    return text.replace(/\((.*?)\)(\d+)/g, (_, char, count) => {
        return char.repeat(Number(count));
    });
}

// 4. parse do .tnl
function parseTNL(raw) {
    const lines = raw.split("\n").map(l => l.trim()).filter(Boolean);

    let lang = "";
    let dict = {};
    let prefix = "";
    let rules = [];

    for (let line of lines) {

        // linguagem
        if (!lang) {
            lang = line;
            dict = loadLanguage(lang);
            continue;
        }

        // prefixo
        if (line.startsWith("Prefix:")) {
            prefix = line.split(":")[1].trim();
            continue;
        }

        // regra If
        if (line.startsWith("If")) {
            const match = line.match(/If"(.*)"/);
            if (match) {
                rules.push({ input: match[1], output: "" });
            }
            continue;
        }

        // saída
        if (line.startsWith("S")) {
            const match = line.match(/S"(.*)"/);
            if (match && rules.length) {
                rules[rules.length - 1].output = match[1];
            }
        }
    }

    return { dict, prefix, rules };
}

// 5. executa input
function run(input, data) {

    for (let r of data.rules) {
        if (input === r.input || input === data.prefix + r.input) {

            let out = r.output;

            // repetição
            out = applyRepeats(out);

            // abreviações (DEPOIS repetição)
            out = applyAbbreviations(out, data.dict);

            console.log(out);
            return;
        }
    }

    console.log("null");
}

// RUN
const raw = fs.readFileSync("repo/excode/exampleptbr.tnl", "utf-8");
const data = parseTNL(raw);

run("oi", data);